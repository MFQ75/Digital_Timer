/* 
 * File:   edit_time_date.h
 * Author: mdfai
 *
 * Created on 20 October, 2023, 12:21 PM
 */

#ifndef EDIT_TIME_DATE_H
#define	EDIT_TIME_DATE_H

unsigned char set_time(unsigned char key);
unsigned char set_date(unsigned char key);
void get_time();

#endif	/* EDIT_TIME_DATE_H */

