/* 
 * File:   view_edit_event.h
 * Author: mdfai
 *
 * Created on 22 October, 2023, 12:21 PM
 */

#ifndef VIEW_EDIT_EVENT_H
#define	VIEW_EDIT_EVENT_H

void view_event(unsigned char key);
unsigned char set_ev(unsigned char key);
void store();

#endif	/* VIEW_EDIT_EVENT_H */

